# First Python Package
This is a simple package containing one class - A gaussian process class with some different kernels from which you can draw samples and then plot them.
